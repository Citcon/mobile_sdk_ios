//
//  CPay.h
//  CPay
//
//  Created by long.zhao on 3/25/22.
//

#import <Foundation/Foundation.h>
#import "CPayDefines.h"
#import "CPayManager.h"
#import "CPayOrder.h"
#import "CPayOrderResult.h"
#import "CPayCheckResult.h"

//! Project version number for CPay.
FOUNDATION_EXPORT double CPayVersionNumber;

//! Project version string for CPay.
FOUNDATION_EXPORT const unsigned char CPayVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CPay/PublicHeader.h>


