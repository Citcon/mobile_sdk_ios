//
//  ViewController.h
//  CPayTest
//
//  Created by Siwei Y. on 6/5/17.
//  Copyright © 2017 Dinolab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

