//
//  AppDelegate.m
//  CPayTest
//
//  Created by Siwei Y. on 6/5/17.
//  Copyright © 2017 Dinolab. All rights reserved.
//

#import "AppDelegate.h"
#import <CPay/CPay.h>

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // set your Merchant token and setup your wechat app id from open.weixin.qq.com in [Info.plist]
    /*
     * For WechatPay Test, please uncomment code below and set pay mode to DEV,
     * and the Wechat AppId and UniversalLink (from open.weixin.qq.com) is required, also you have to set the associated domain
     * via: Targets -> Your Project -> Signing & Capabilities -> Associated Domain(add it if NOT exsits)
     */
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options {
    NSLog(@"UIApplicationOpenURLOptionsKey: %@ options: %@", url, options);
    BOOL processed = [CPayManager processOpenUrl:app url:url standbyCallback:^(CPayOrderResult *result) {
        NSLog(@"\nopenURL result: %@ status: %li, message: %@, transaction id: %@", result.result, result.resultStatus, result.message, result.order.transactionId);
    }];
    
    if (processed) {
        return YES;
    }
    return YES;
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    return [self application:application openURL:url options:@{}];
}

- (BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void (^)(NSArray<id<UIUserActivityRestoring>> * _Nullable))restorationHandler {
    NSLog(@"\napplication:continueUserActivity: %@", userActivity.webpageURL.absoluteURL);
    [CPayManager processUserActivity:userActivity];
    return YES;
}

@end
