//
//  ViewController.m
//  CPayTest
//
//  Created by Siwei Y. on 6/5/17.
//  Copyright © 2017 Dinolab. All rights reserved.
//

#import "ViewController.h"
#import <CPay/CPay.h>
//#import <CPayEmbeded/CPay.h>


@interface ViewController () <UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *txtReference;
@property (weak, nonatomic) IBOutlet UITextField *txtSubject;
@property (weak, nonatomic) IBOutlet UITextField *txtBody;
@property (weak, nonatomic) IBOutlet UITextField *txtAmount;
@property (weak, nonatomic) IBOutlet UITextField *txtCurrency;
@property (weak, nonatomic) IBOutlet UITextField *txtVendor;
@property (weak, nonatomic) IBOutlet UITextField *txtIpnUrl;
@property (weak, nonatomic) IBOutlet UITextField *txtCallback;
@property (weak, nonatomic) IBOutlet UISwitch *optDuplicate;
@property (weak, nonatomic) IBOutlet UILabel *txtResult;

- (IBAction)onCheckOrder:(id)sender;
@property (nonatomic, assign) BOOL requesting;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _txtResult.text = @"";
    
    _txtReference.text = @"pay-mobile-test";
    _txtSubject.text = @"测试";
    _txtBody.text = @"我是测试数据";
    _txtAmount.text = @"1";
    _txtCurrency.text = @"USD";                                                     //currency, eg. USD, CNY
    _txtVendor.text = @"wechatpay";                                                 //vendor (wechatpay, alipay)
    _txtIpnUrl.text = @"https://uat.citconpay.com/payment/notify_wechatpay.php";    //notify url
    _txtCallback.text = @"http://www.google.com";                                   //callbacl url
    _optDuplicate.selected = YES;
    
    // TODO: For RMB Currency Payment testing, please uncomment the code below
    // [self _supportRMBPay];
    
    // Observe the kOrderPaymentFinishedNotification notification, will be called after the payment finished.
    [[NSNotificationCenter defaultCenter]addObserver:self
                                            selector:@selector(cpay_inquired_order:)
                                                name:kOrderPaymentFinishedNotification
                                              object:nil];
}

- (void)_supportRMBPay {
    _txtReference.text = @"CNY-mobile-test";
    _txtCurrency.text = @"CNY";
    _txtIpnUrl.text = @"http://52.87.248.227/ipn.php";
    [CPayManager setupMode:CPayModePROD];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onOrderPressed:(id)sender {
    if (_requesting) { return; }
    
    // create request order by detail parameters
    //[self requestOrderByDetails];
    //return;
    
    // create request order by order object
    CPayOrder * order = [CPayOrder new];
    order.referenceId = _txtReference.text;
    order.subject = _txtSubject.text;
    order.body = _txtBody.text;
    order.amount = _txtAmount.text;
    order.currency = _txtCurrency.text;
    order.vendor = _txtVendor.text;
    order.ipnUrl = _txtIpnUrl.text;
    order.callbackUrl = _txtCallback.text;
    order.allowDuplicate = _optDuplicate.selected;
    order.scheme = @"cpaydemo.citconpay.com";  // (required) your app scheme for alipay payment, set in the Info.plist
    
    _txtResult.text = @"REQUESTING ...";
    _requesting = YES;
    
    [CPayManager requestOrder:order completion:^(CPayOrderResult * payResult) {
        // if resultStauts == kOrderPaymentCancelledByUserCode, means it was been cancelled by user.
        NSLog(@"result:%@, status:%lu",payResult.message, payResult.resultStatus);
        _requesting = NO;
    }];
}

- (void)requestOrderByDetails {
    [CPayManager requestOrder:_txtReference.text
                      subject:_txtSubject.text
                         body:_txtBody.text
                       amount:_txtAmount.text
                     currency:_txtCurrency.text
                       vendor:_txtVendor.text
                       ipnUrl:_txtIpnUrl.text
                  callbackUrl:_txtCallback.text
               allowDuplicate:_optDuplicate.selected
                       scheme:@"cpaydemo.citconpay.com"
                   completion:^(CPayOrderResult *result) {
                       // if resultStauts == kOrderPaymentCancelledByUserCode, means it was been cancelled by user.
                       NSLog(@"result:%@, status:%lu",result.message, result.resultStatus);
                       _requesting = NO;
    }];
}

- (BOOL) textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)cpay_inquired_order:(NSNotification *)notification {
    CPayCheckResult *checkResult = (CPayCheckResult *) notification.object;
    [self showCPayResult:checkResult];
}

- (void)showCPayResult:(CPayCheckResult*)checkResult {
    NSMutableString * result = [NSMutableString new];
    [result appendFormat:@"- CHECK RESULT\n"];
    [result appendFormat:@"    TRANSACTION_ID: %@\n", checkResult.transactionId];
    [result appendFormat:@"    REFERENCE_ID  : %@\n", checkResult.referenceId];
    [result appendFormat:@"    TYPE: %@  TIME: %@\n", checkResult.type, checkResult.time];
    [result appendFormat:@"    STATUS: %@  AMOUNT: %@ (%@)\n", checkResult.status, checkResult.amount, checkResult.currency];
    [result appendFormat:@"    REFUND_STATUS: %@  AMOUNT: %@\n", checkResult.refund_status, checkResult.refunded_amount];
    [result appendFormat:@"    NOTE: %@\n", checkResult.note];
    self.txtResult.text = result;
}

// Example of inquire history order, transaction id is required
- (IBAction)onCheckOrder:(id)sender {
    CPayOrder *historyOrder = [CPayOrder new];
    historyOrder.currency = @"USD"; //default value
    
    //TODO: pass in your transaction id
    NSString *transactionId = @"U0000001997-a4c66b6f74836bdbfbc9";
    
    [CPayManager inquireResult:transactionId order:historyOrder method:NULL completion:^(CPayCheckResult *result) {
        [self showCPayResult:result];
    }];
}
@end
