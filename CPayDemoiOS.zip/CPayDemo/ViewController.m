//
//  ViewController.m
//  CPayTest
//
//  Created by Siwei Y. on 6/5/17.
//  Copyright © 2017 Dinolab. All rights reserved.
//

#import "ViewController.h"
#import <CPay/CPay.h>
#import "LoadingView.h"

@interface ViewController () <UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource>

@property (weak, nonatomic) IBOutlet UITextField *txtReference;
@property (weak, nonatomic) IBOutlet UITextField *txtSubject;
@property (weak, nonatomic) IBOutlet UITextField *txtBody;
@property (weak, nonatomic) IBOutlet UITextField *txtAmount;
@property (weak, nonatomic) IBOutlet UITextField *txtCurrency;
@property (weak, nonatomic) IBOutlet UITextField *txtVendor;
@property (weak, nonatomic) IBOutlet UITextField *txtIpnUrl;
@property (weak, nonatomic) IBOutlet UITextField *txtCallback;
@property (weak, nonatomic) IBOutlet UISwitch *optDuplicate;
@property (weak, nonatomic) IBOutlet UILabel *txtResult;
@property (weak, nonatomic) IBOutlet UITextField *txtCountry;
@property (weak, nonatomic) IBOutlet UISwitch *optIsAccerelation;

@property (weak, nonatomic) IBOutlet UITextField *txtExtKey;
@property (weak, nonatomic) IBOutlet UITextField *txtExtValue;
@property (weak, nonatomic) IBOutlet UITextField *txtEnvValue;
@property (weak, nonatomic) IBOutlet UITextField *txtTokenValue;
@property (weak, nonatomic) IBOutlet UITextField *txtInquireKey;
@property (weak, nonatomic) IBOutlet UILabel *lblVersion;

- (IBAction)onCheckOrder:(id)sender;
@property (nonatomic, assign) BOOL requesting;
@property (strong, nonatomic) UIPickerView *picker;
@property (strong, nonatomic) NSArray *vendors;
@property (strong, nonatomic) NSArray *currencies;
@property (strong, nonatomic) NSArray *envs;
@property (strong, nonatomic) NSArray *pickerData;
@property (strong, nonatomic) NSArray *countries;
@property (strong, nonatomic) NSDictionary *tokens;
@property (strong, nonatomic) UITextField *currentTextField;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initPlaceholders];
    [self initPickerData];
    [self initUIPicker];
    [self initVersionInfo];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    // Register an observer to receive the notification of automatically query
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(cpay_inquired_order:)
                                                 name:kOrderPaymentFinishedNotification
                                               object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    // Unregister all observer
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kOrderPaymentFinishedNotification object:nil];
}

#pragma mark - Initialize UI view

- (void)initVersionInfo {
    _lblVersion.text = [NSString stringWithFormat:@"SDK Version: %@", [CPayManager getVersion]];
}

- (void)initPlaceholders {
    _txtResult.text = @"";
    _txtReference.text = @"";
    _txtSubject.text = @"test subject";
    _txtBody.text = @"test body";
    _txtAmount.text = @"1";
    _txtCurrency.text = @"USD";
    _txtCountry.text = @"US";
    _txtVendor.text = @"upop";
    _txtIpnUrl.text = @"https://merchant.com/ipn.php";
    _txtCallback.text = @"cpaydemo.citconpay.com://";
    _optDuplicate.on = YES;
    _txtTokenValue.text = @"9FBBA96E77D747659901CCBF787CDCF1";
    _txtEnvValue.text = @"DEV";
    _optIsAccerelation.on = NO;
    _txtInquireKey.text = @"";
    
    _txtExtKey.text = @"reference2";
    _txtExtValue.text = @"123456789";
}

#pragma mark - Initialize UI Picker
- (void)initUIPicker {
    _picker = [[UIPickerView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height/3)];
    [_picker setBackgroundColor:[UIColor systemGrayColor]];
    [_picker setDataSource:self];
    [_picker setDelegate:self];
    [self.view addSubview:_picker];
    
    [self initUIPickerGesture];
}

- (void)initUIPickerGesture {
    [self addPickerGesture:_txtVendor action:@selector(onVendorTapped)];
    [self addPickerGesture:_txtCurrency action:@selector(onCurrencyTapped)];
    [self addPickerGesture:_txtEnvValue action:@selector(onEnvTapped)];
    [self addPickerGesture:_txtCountry action:@selector(onCountryTapped)];
    [self addPickerGesture:self.view action:@selector(hidePicker)];
}

- (void)addPickerGesture:(nullable id)txtField action:(nullable SEL)action {
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:action];
    [txtField addGestureRecognizer:tap];
}

- (void)showUIPicker {
    self.picker.alpha = 1;
    [UIView animateWithDuration:0.3 animations:^{
        self.picker.frame = CGRectMake(0, self.view.frame.size.height*.67, self.view.frame.size.width, self.view.frame.size.height/3);
    } completion:^(BOOL finished) {
        [self.picker reloadAllComponents];
    }];
}

#pragma mark - Initialize UI Picker Data
- (void)initPickerData {
    _vendors = @[
        @"wechatpay", @"wechatpay_h5", @"alipay", @"upop", @"alipay_hk", @"kakaopay",
        @"gcash", @"dana", @"truemoney", @"bkash", @"easypaisa", @"cc", @"jkopay",
        @"card", @"payco", @"naverpay", @"banktransfer", @"linepay", @"paypay", @"rakutenpay"
    ];
    _currencies = @[
        @"USD", @"CNY", @"HKD", @"IDR", @"PHP", @"KRW", @"GBP", @"EUR", @"SGD",
        @"AUD", @"TWD", @"CAD", @"JPY"
    ];
    _envs = @[
        @"DEV", @"QA", @"PROD", @"UAT"
    ];
    _countries = @[
        @"US", @"KR", @"JP", @"CN", @"HK", @"CA"
    ];
}

# pragma mark - delegate & datasource
- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component {
    return 30;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    NSString *_d = self.pickerData[row];
    if (_d) self.currentTextField.text = _d;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return self.pickerData.count;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    return self.pickerData[row];
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

#pragma mark - UI Picker SEL
- (void)onVendorTapped {
    self.currentTextField = _txtVendor;
    self.pickerData = self.vendors;
    [self showUIPicker];
}

- (void)onCurrencyTapped {
    self.currentTextField = _txtCurrency;
    self.pickerData = self.currencies;
    [self showUIPicker];
}

- (void)onEnvTapped {
    self.currentTextField = _txtEnvValue;
    self.pickerData = self.envs;
    [self showUIPicker];
}

- (void)onCountryTapped {
    self.currentTextField = _txtCountry;
    self.pickerData = self.countries;
    [self showUIPicker];
}

- (void)hidePicker {
    [UIView animateWithDuration:0.3 animations:^{
        self.picker.frame = CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height/3);
    } completion:^(BOOL finished) {
        self.picker.alpha = 0;
    }];
}

#pragma mark - Helpers
- (void)showAlert:(NSString *)title message:(NSString *)message {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *act = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    [alert addAction:act];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)checkInstalled:(NSString *)vendor {
    // Key: vendor - Value: function name
    NSDictionary *checks = @{
        @"wechatpay": @"isWechatInstalled",
        @"alipay": @"isAlipayInstalled",
        @"alipay_hk": @"isAlipayHKInstalled",
        @"kakaopay": @"isKakaoPayInstalled",
        @"upop": @"isUnionPayInstalled",
        @"gcash": @"isGcashInstalled",
        @"payco": @"isPaycoPayInstalled",
        @"naverpay": @"isNaverInstalled",
        @"linepay": @"isLinePayInstalled",
        @"paypay": @"isPayPayInstalled",
        @"rakutenpay": @"isRakutenPayInstalled"
    };
    NSString *method = [checks objectForKey:vendor];
    if (method != nil) {
        SEL sel = NSSelectorFromString(method);
        if ([CPayManager respondsToSelector:sel]) {
            BOOL appInstalled = [CPayManager performSelector:sel];
            [self showAlert:@"Installation Check" message:[NSString stringWithFormat:@"%@ installed: %@", vendor, appInstalled ? @"YES" : @"NO"]];
        }
    }
}

- (void)generateRef {
    _txtReference.text = [NSString stringWithFormat:@"CPayDemoTest_%ld", (long)[[NSDate date] timeIntervalSince1970]*1000000];
}

- (CPayOrder *)createOrderFromUISet {
    CPayOrder * order = [CPayOrder new];
    order.referenceId = _txtReference.text;
    order.subject = _txtSubject.text;
    order.body = _txtBody.text;
    order.amount = _txtAmount.text;
    order.currency = _txtCurrency.text;
    order.vendor = _txtVendor.text;
    order.ipnUrl = _txtIpnUrl.text;
    order.allowDuplicate = _optDuplicate.isOn;
    
    // If you use alipay_hk/kakaopay/dana/kcp/sbps, set as URLScheme of your info.plist
    order.callbackUrl = _txtCallback.text;
    order.callbackFail = _txtCallback.text;
    order.cancelUrl = _txtCallback.text;
    
    // required for upop payment
    order.controller = self;
    // (required) your app scheme for alipay payment, set in the Info.plist
    order.scheme = @"cpaydemo.citconpay.com";
    // (required) your app universal link if you are using wechat pay
    order.universalLink = @"https://dev.citconpay.com/cpaydemo";
    
    // If you use kcp/sbps, set following values
    order.country = _txtCountry.text;
    order.firstName = @"John";
    order.lastName = @"Doe";
    order.phone = @"6145675309";
    order.email = @"test.sam@test.com";
    order.consumerReference = @"consumer-reference-000";
    order.taxableAmount = 0;
    order.taxExemptAmount = 0;
    order.totalTaxAmount = 0;
    order.isAccelerateCNPay = _optIsAccerelation.isOn;
    
    order.extra = [self getExtra];
    
    return order;
}

- (NSString*)dict2jsonString:(id)object {
    NSString *jsonString = @"{}";
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:object
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    if (jsonData) {
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    NSMutableString *mutStr = [NSMutableString stringWithString:jsonString];
    
    //remove whitespace character
    NSRange range = {0,jsonString.length};
    [mutStr replaceOccurrencesOfString:@" " withString:@"" options:NSLiteralSearch range:range];
    
    //remvoe new line character
    NSRange range2 = {0,mutStr.length};
    [mutStr replaceOccurrencesOfString:@"\n" withString:@"" options:NSLiteralSearch range:range2];

    return mutStr;
}

- (NSString*)getExtra {
    NSString *_extraKey = [_txtExtKey.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *_extraVal = [_txtExtValue.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    return [self dict2jsonString:@{_extraKey: _extraVal}];
}

- (void)setRuntimeEnv {
    NSDictionary *modes = @{
        @"QA": @(CPayModeQA),
        @"DEV": @(CPayModeDEV),
        @"PROD": @(CPayModePROD),
        @"UAT": @(CPayModeUAT)
    };
    [CPayManager setupMode:[modes[_txtEnvValue.text] intValue]];
}

- (void)setRuntimeToken {
    if (_txtTokenValue.text.length > 0) {
        [CPayManager setupTokenKey:_txtTokenValue.text];
    }
}

- (void)clearResult {
    self.txtResult.text = @"";
}

- (void)showOrderResult:(CPayOrderResult *)result {
    NSMutableString *str = [NSMutableString new];
    [str appendFormat:@"CPayOrder Result\n"];
    [str appendFormat:@"    status: %ld\n", (long)result.resultStatus];
    [str appendFormat:@"    message: %@\n", result.message];
    [str appendFormat:@"    result: %@\n", result.result];
    [str appendFormat:@"    vendor: %@\n", result.order.vendor];
    [str appendFormat:@"    txn id: %@\n", result.order.transactionId];
    [str appendFormat:@"    ref id: %@\n", result.order.referenceId];
    [str appendFormat:@"    currency: %@ amount: %@\n", result.order.currency, result.order.amount];
    
    if (self.txtResult.text == nil || self.txtResult.text.length < 1) {
        self.txtResult.text = str;
        return;
    }
    self.txtResult.text = [NSString stringWithFormat:@"%@\n\n%@", self.txtResult.text, str];
}

- (void)showCheckResult:(CPayCheckResult *)result {
    NSMutableString *str = [NSMutableString new];
    [str appendFormat:@"CPayCheck Result\n"];
    [str appendFormat:@"    status: %@\n", result.status];
    [str appendFormat:@"    type: %@\n", result.type];
    [str appendFormat:@"    txn id: %@\n", result.transactionId];
    [str appendFormat:@"    ref id: %@\n", result.referenceId];
    [str appendFormat:@"    currency: %@ amount: %@\n", result.currency, result.amount];
    [str appendFormat:@"    refunded amount: %@ time: %@", result.refunded_amount, result.time];
    
    if (self.txtResult.text == nil || self.txtResult.text.length < 1) {
        self.txtResult.text = str;
        return;
    }
    self.txtResult.text = [NSString stringWithFormat:@"%@\n\n%@", self.txtResult.text, str];
}

- (void)showNotification:(nonnull CPayCheckResult *)result {
    NSMutableString *str = [NSMutableString new];
    [str appendFormat:@"Notification Result\n"];
    [str appendFormat:@"    status: %@\n", result.status];
    [str appendFormat:@"    type: %@\n", result.type];
    [str appendFormat:@"    txn id: %@\n", result.transactionId];
    [str appendFormat:@"    ref id: %@\n", result.referenceId];
    [str appendFormat:@"    currency: %@ amount: %@\n", result.currency, result.amount];
    [str appendFormat:@"    refunded amount: %@ time: %@", result.refunded_amount, result.time];
    
    if (self.txtResult.text == nil || self.txtResult.text.length < 1) {
        self.txtResult.text = str;
        return;
    }
    self.txtResult.text = [NSString stringWithFormat:@"%@\n\n%@", self.txtResult.text, str];
}

- (void)showResult:(_Nonnull id)result {
    if ([result isKindOfClass:[CPayOrderResult class]]) {
        [self showOrderResult:result];
    } else if ([result isKindOfClass:[CPayCheckResult class]]) {
        [self showCheckResult:result];
    }
}

- (void)updateTxnId:(CPayOrderResult *)result {
    self.txtInquireKey.text = result.order.transactionId != nil ? result.order.transactionId : @"";
}

- (void)updateRefId:(CPayOrderResult *)result {
    self.txtInquireKey.text = result.order.referenceId != nil ? result.order.referenceId : @"";
}

#pragma mark - UI SEL event

- (BOOL) textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (IBAction)onOrderPressed:(id)sender {
    [self generateRef];
    CPayOrder *order = [self createOrderFromUISet];
    
    [self setRuntimeEnv];
    [self setRuntimeToken];
    
    [self clearResult];
    [LoadingView show:self];
    //@weakify(self)
    [CPayManager requestOrder:order completion:^(CPayOrderResult * payResult) {
        [LoadingView dismiss];
        
        _txtInquireKey.text = payResult.order.transactionId;
        [self showResult: payResult];
    }];
}

// Example of inquire history order, transaction id is required
- (IBAction)onCheckOrder:(id)sender {
    [self setRuntimeEnv];
    [self setRuntimeToken];
    
    if (self.txtInquireKey.text == nil || self.txtInquireKey.text.length < 1) {
        [self showAlert:@"Error" message:@"Empty transaction id"];
        return;
    }
    
    [self clearResult];
    [LoadingView show:self];
    [CPayManager inquireResult:self.txtInquireKey.text
                         order:[self createOrderFromUISet]
                        method:@"real" completion:^(CPayCheckResult *result) {
        [LoadingView dismiss];
        
        [self showResult:result];
    }];
}

- (IBAction)checkOrderByRef:(id)sender {
    [self setRuntimeEnv];
    [self setRuntimeToken];
    
    if (self.txtReference.text == nil || self.txtReference.text.length < 1) {
        [self showAlert:@"Error" message:@"Empty reference id"];
        return;
    }
    
    [self clearResult];
    [LoadingView show:self];
    [CPayManager inquireResultByRef:_txtReference.text
                           currency:_txtCurrency.text
                             method:@"real"
                             vendor:_txtVendor.text
                      isAccelerated:_optIsAccerelation.selected completion:^(CPayCheckResult *result) {
        [LoadingView dismiss];
        
        [self showResult:result];
    }];
}

- (IBAction)onClickBlank:(id)sender {
    [self.view endEditing:YES];
}

- (IBAction)onCheckAppInstalled:(id)sender {
    if (_txtVendor.text == nil || _txtVendor.text.length < 1) {
        [self showAlert:@"Error" message:@"Vendor can not be empty."];
        return;
    }
    [self checkInstalled:_txtVendor.text];
}

#pragma mark - Observer

- (void)cpay_inquired_order:(NSNotification *)notification {
    [self showAlert:@"Notification" message:@"onResult Notification"];
    
    CPayCheckResult *checkResult = (CPayCheckResult *) notification.object;
    [self showNotification:checkResult];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
